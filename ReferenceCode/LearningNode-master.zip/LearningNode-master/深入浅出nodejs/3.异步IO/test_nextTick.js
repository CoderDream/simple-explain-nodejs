process.nextTick(function() {
  console.log(1234);
})