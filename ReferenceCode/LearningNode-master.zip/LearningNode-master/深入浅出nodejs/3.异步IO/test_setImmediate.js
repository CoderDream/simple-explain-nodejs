setImmediate(function() {
  console.log(1234);
})