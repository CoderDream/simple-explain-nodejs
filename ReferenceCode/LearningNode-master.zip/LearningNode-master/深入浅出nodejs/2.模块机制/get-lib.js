const path = require('path');
const data = path.resolve(process.execPath, '..', '..', 'lib', 'node_module');
console.log(data);