console.log(require);
console.log("-----");
console.log(module);
console.log("-----");
console.log(exports);